#!/sbin/sh



# Example:


# ui_print "Applying update..."
#
# package_extract_file newbinary $INSTALLDIR/newbinary
#
# mv $INSTALLDIR/newbinary /system/bin/newbinary
#
# set_metadata /system/bin/newbinary uid root gid shell mode 755
#
# 
# ui_print "Update successfully installed!"


